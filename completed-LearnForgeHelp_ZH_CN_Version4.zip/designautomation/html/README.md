# 基本 UI

界面基于 vanilla `HTML5` 和 `JavaScript`。对于任何服务器端，它本质上是相同的，但存在一些差异：Websocket 实现使用 socket.io (Node.js) 或 SignalR (.NET Core)。

选择您的语言：[Node.js](designautomation/html/nodejs.md) | [.NET Core](designautomation/html/netcore.md)