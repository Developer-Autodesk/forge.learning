# 上传 AppBundle

现在 ZIP 包已准备就绪，让我们上传到 Design Automation。

选择您的语言：[Node.js](designautomation/appbundle/nodejs) | [.NET Core](designautomation/appbundle/netcore)