# 定义 Activity

Activity 是指可以使用指定引擎执行的动作的规范。它指定输入和输出文件的数量，以及要使用的 AppBundle 和入口点。

在本教程示例中，activity 有 2 个输入（文件和 JSON 数据）和 1 个输出（文件）。

选择您的语言：[Node.js](designautomation/activity/nodejs) | [.NET Core](designautomation/activity/netcore)