# 定义 Activity (Node.js)

**Activity**

现在，我们将编写 endpoint 以创建新 activity 和获取现有 activity，将以下代码复制到 `DesignAutomation.js` 文件中的最后一行 `module.exports = router;` 之前：

[routes/DesignAutomation.js](_snippets/modifymodels/node/routes/DesignAutomation.3.js ':include :type=code javascript')

现在，您可以单击右上角的 **Configure**，选择“AppBundle”和“Engine”，然后单击 **Define Activity**，这应该会定义并上传 AppBundle 并定义 Activity。左侧的结果面板显示各自的 ID。**所有其他按钮仍不起作用**... 我们继续。

![](_media/designautomation/define_activity.gif)

下一步：[执行 Workitem](designautomation/workitem/README.md)