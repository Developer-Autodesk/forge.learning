# 工具 (Node.js)

安装 [Node.js](http://nodejs.org) 引擎以运行代码。安装 [NPM](https://www.npmjs.com/get-npm) 依存关系管理器以安装软件包。

现在，我们需要 IDE 来编写代码。有许多选项，本教程将使用 [Visual Studio Code](https://code.visualstudio.com/)。

> 在本教程中，使用所有默认安装选项。

下一步：[身份验证](oauth/)