# 在本地运行和调试

您要参考哪个教程？

- [查看模型](environment/rundebug/2legged.md)


- [查看 BIM 360 和 Fusion 模型](environment/rundebug/3legged.md)


- [修改模型](environment/rundebug/2legged_da.md)