# 运行和调试 (Node.js)

转到 **Debug** 菜单，然后选择 **Start debugging**。底部应显示“Debug Console”选项卡，如下所示：

![](_media/nodejs/vs_code_debug.png) 

打开浏览器，然后访问 [http://localhost:3000](http://localhost:3000)。

下一步：[部署](deployment/)