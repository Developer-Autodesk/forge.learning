# 运行和调试 (.NET)

我们在 Visual Studio 中创建的 WebAPI 项目没有文件，因此，当我们启动它时，不会运行任何项。由于我们的 **forgesample** 项目现在包含 `index.html`，因此只需右键单击它并选择 **Set as Start Page**。

Visual Studio 应该会识别计算机上的所有浏览器并列出它们以便启动项目。只需选择一个浏览器，然后单击“Play”图标。浏览器应该会打开并显示起始页面。

![](_media/net/start_debug.png) 

下一步：[Viewer 扩展](tutorials/extensions)