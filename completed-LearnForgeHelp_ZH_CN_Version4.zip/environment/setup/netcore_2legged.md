[net 设置](environment/setup/netcore.md ':include :type=markdown')

下一步：[身份验证](oauth/2legged/)
