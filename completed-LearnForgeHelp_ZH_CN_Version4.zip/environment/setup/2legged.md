# 创建服务器

您的 Client ID 和 Secret 应受到保护并保持机密，因为您的所有文件都将绑定到您的帐户。对于 Web 应用程序，请将其保留在您的服务器上。本部分演示如何准备创建本地开发服务器。

选择您的语言：[Node.js](environment/setup/nodejs_2legged) | [.NET Framework](environment/setup/net_2legged) | [.NET Core](environment/setup/netcore_2legged) | [Go](environment/setup/go) | [PHP](environment/setup/php) | [Java](environment/setup/java) 

