[net 设置](environment/setup/netcore.md ':include :type=markdown')

下一步：[授权](oauth/3legged/)
