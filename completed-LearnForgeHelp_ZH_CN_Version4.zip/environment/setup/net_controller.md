# 创建 .NET WebAPI 控制器

在项目中，右键单击 **Controllers** 文件夹，然后转到 **Add** >> **Controller**。

![](_media/net/new_controller.png)

接下来，选择 **Web API 2 Controller - Empty**。 

![](_media/net/new_controller_type.png) 

最后，输入控制器的名称。

!> 控制器**必须**具有 **Controller** 后缀。

:arrow_backward:在浏览器上单击 **Back** 