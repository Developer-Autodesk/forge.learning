# Heroku (Nodejs)

[步骤 1](/deployment/heroku/heroku_step1.md ':include :type=markdown')

我们使用 Node 的 GitHub 模板：https://github.com/github/gitignore/blob/master/Node.gitignore

[步骤 2](/deployment/heroku/heroku_step2.md ':include :type=markdown')

```bash
heroku create forgesample
heroku git:remote -a forgesample
```

[步骤 3](/deployment/heroku/heroku_step3.md ':include :type=markdown')