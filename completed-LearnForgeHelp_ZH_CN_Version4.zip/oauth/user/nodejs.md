# 用户信息 (Node.js)

此 endpoint 将请求最终用户信息并返回**名称**和**图片** (40px)。

## routes/user.js

创建 `routes/user.js` 文件并复制以下内容：

[routes/user.js](_snippets/viewhubmodels/node/routes/user.js ':include :type=code javascript')

下一步：[在 Viewer 上显示](viewer/3legged/readme)