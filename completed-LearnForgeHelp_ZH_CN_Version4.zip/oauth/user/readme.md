# 用户信息

使用三条腿访问 token 时，我们可以获取授权最终用户的个人资料信息。其中包括**名称**和**图片**，这对于更好地自定义用户界面很有用。[了解更多信息](https://forge.autodesk.com/en/docs/oauth/v2/reference/http/users-@me-GET/)

选择您的语言：[Node.js](oauth/user/nodejs) | [.NET Framework](oauth/user/net) | [.NET Core](oauth/user/netcore)
