# 用户信息

此 endpoint 将请求最终用户信息并返回**名称**和**图片** (40px)。

## UserController.cs

在 **Controllers** 文件夹下，在类文件 (`UserController.cs`) 中创建一个名为 **UserController** 的类（类与类文件名称相同），并添加以下内容：

[UserController.cs](_snippets/viewhubmodels/netcore/UserController.cs ':include :type=code csharp')

下一步：[在 Viewer 上显示](viewer/3legged/readme)