# 用户信息 (.NET Framework)

此 endpoint 将请求最终用户信息并返回**名称**和**图片** (40px)。

## UserController.cs

创建一个名为 **UserController** 的 .NET WebAPI 控制器（请参见[如何创建控制器](environment/setup/net_controller)），并添加以下内容：

[UserController.cs](_snippets/viewhubmodels/net/UserController.cs ':include :type=code csharp')

下一步：[在 Viewer 上显示](viewer/3legged/readme)