# 客户端文件 (Go)

我们的 Go 服务器配置为从 `/www/` 文件夹提供文件。我们按如下所示进行组织：

- `/www/`：`.html` 
- `/www/js`：`.js`
- `/www/css`：`.css`

下图显示了此结构（在下一部分中创建文件后）

![](_media/go/vs_code_allfiles_ui.png)