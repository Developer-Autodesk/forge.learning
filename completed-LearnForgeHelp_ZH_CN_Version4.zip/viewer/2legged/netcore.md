[.NET Core 设置](viewer/netcore.md ':include :type=markdown')

![](_media/netcore/project_all_files.png)

下一步：[Viewer（客户端）](viewer/2legged/ui)
