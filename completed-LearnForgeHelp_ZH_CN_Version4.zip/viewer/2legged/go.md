[nodejs 设置](viewer/go.md ':include :type=markdown')

下一步：[Viewer（客户端）](viewer/2legged/ui)