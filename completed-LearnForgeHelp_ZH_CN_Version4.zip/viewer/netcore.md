# 客户端文件 (.NET Core)

通常，ASP.NET Core 应用程序从 `/wwwroot/` 文件夹提供文件，如果还没有该文件夹，则会创建。在该文件夹下，我们按如下所示进行组织：

- `wwwroot/`：`.html`
- `wwwroot/js`：`.js`
- `wwwroot/css`：`.css`

下图说明了我们的文件和文件夹结构（在下一部分中创建文件和文件夹后）：