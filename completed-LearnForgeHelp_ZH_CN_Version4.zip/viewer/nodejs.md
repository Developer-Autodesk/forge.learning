# 客户端文件 (Node.js)

我们的 Node.js 服务器配置为从 `public` 文件夹提供文件。我们按如下所示组织其内容：

- `public/`：`.html` 
- `public/js`：`.js`
- `public/css`：`.css`

下图显示了预期结构（在下一部分中创建文件后）：

![](_media/nodejs/vs_code_allfiles_ui.png)