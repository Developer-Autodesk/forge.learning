# 您的第一个面板

本教程将指导您如何读取数据并创建一些图表。 

![](_media/tutorials/run_sample_dashboard.gif)

> 在本教程中，您需要一个带有 Viewer 的应用程序，例如，[查看模型](tutorials/viewmodels.md)或[查看 BIM 360 和 Fusion 模型](tutorials/viewhubmodels.md)教程中使用的应用程序。无论文件托管在何处，Viewer 都是相同的。

准备好开始编码了吗？

下一步：[调整布局](viewer/dashboard/layout.md)