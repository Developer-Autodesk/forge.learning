# 執行和除錯 (NodeJS)

移往 **Debug** 功能表，然後選取 **Start debugging**。「Debug Console」頁籤應會出現在底部，如下所示：

![](_media/nodejs/vs_code_debug.png) 

開啟您的瀏覽器，然後移往 [http://localhost:3000](http://localhost:3000)。

下一步：[Viewer 擴充功能](tutorials/extensions)