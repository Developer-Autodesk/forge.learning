# 在本端執行和除錯

您該照著哪個自學課程操作？

- [檢視模型](environment/rundebug/2legged.md)


- [檢視 BIM 360 與 Fusion 模型](environment/rundebug/3legged.md)


- [修改模型](environment/rundebug/2legged_da.md)