# 執行和除錯 (.NET)

我們在 Visual Studio 上建立的 WebAPI 專案中是沒有檔案的，因此當我們啟動該專案時，什麼都不會執行。由於我們的 **forgesample** 專案現在包含 `index.html`，請直接在其上按一下右鍵，然後選取 **Set as Start Page**。

Visual Studio 應會辨識並列出電腦上的所有瀏覽器，以供您啟動專案。您只需選取其中一個瀏覽器，然後按一下「播放」圖示。該瀏覽器應會開啟並顯示您的起始頁。

![](_media/net/start_debug.png) 

下一步：[Viewer 擴充功能](tutorials/extensions)