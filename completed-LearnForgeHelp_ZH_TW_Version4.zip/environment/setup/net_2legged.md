[net 設定](environment/setup/net.md ':include :type=markdown')

專案已準備就緒！

下一步：[驗證](oauth/2legged/)