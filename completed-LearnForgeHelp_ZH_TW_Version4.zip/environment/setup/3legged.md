# 建立伺服器

您的 Client ID 和 Secret 應受到保護並保持其機密性，因您的所有檔案都與您的開發者帳號繫結在一起，所以在進行網頁應用程式開發時，請確保 Client ID 和 Secret 只存在於您的伺服器上，並未對外曝露。本章節將示範如何建立本地開發用途的伺服器。

請選擇您的語言：[Node.js](environment/setup/nodejs_3legged) | [.NET Framework](environment/setup/net_3legged) | [.NET Core](environment/setup/netcore_3legged) 
