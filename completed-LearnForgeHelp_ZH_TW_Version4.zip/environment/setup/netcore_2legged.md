[net 設定](environment/setup/netcore.md ':include :type=markdown')

下一步：[驗證](oauth/2legged/)
