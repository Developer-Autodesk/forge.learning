# 建立新專案 (Node.js)

在您的電腦上建立資料夾，請勿使用空格並避免使用特殊字元。在本自學課程中，讓我們使用 **forgesample** 作為資料夾名稱。

開啟 **Visual Studio Code**，移往功能表 **File**，並選取 **Open** (MacOS) 或 **Open Folder** (Windows)，然後選取新建立的資料夾。 

現在，我們需要終端機，請移往功能表 **View** >> **Integrated Terminal**。視窗應顯示在底部。輸入下列指令並遵循這些步驟。為了與其他 Forge 範例保持一致，當系統提示輸入 **entry point:** 時，請使用 **start.js**。

```
npm init
```

這會建立 **package.json** 檔案，用於定義專案將使用哪些套件。[瞭解更多](https://docs.npmjs.com/files/package.json)。

## 安裝套件

依預設，Node.js 專案是空的，因此我們需要透過 **npm install** 安裝一些套件。讓我們從以下內容開始：基本 **Express** 伺服器、**body-parser** (用於 JSON 處理)、**multer** (用於檔案上傳)，當然還有 **Autodesk Forge**。

!> 一次執行一個 **npm install**。

```
npm install express --save
npm install multer --save
npm install cookie-session --save
npm install forge-apis --save
```

> `--save` 參數指示模組應作為從屬項包含在 **package.json** 檔案中。

最後，開啟 **package.json**，並在 `"scripts"` 內加入 `"start": "node start.js",` 行。現在，您的資料夾應包含 **node_modules** 資料夾，並且 **package.json** 應如下所示：

```json
{
  "name": "forgesample",
  "version": "1.0.0",
  "description": "",
  "main": "start.js",
  "scripts": {
    "start": "node start.js",
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC",
  "dependencies": {
    "cookie-session": "^2.0.0-beta.3",
    "express": "^4.16.2",
    "forge-apis": "^0.4.1",
    "multer": "^1.3.0"
  }
}

```

> 版本號碼 (例如 forge-apis 0.4.1) 可能有所不同，這是建立本自學課程時的最新版本。

## 檔案和資料夾

若要建立新資料夾或檔案，請在左側的「Explorer」區域上按一下右鍵，然後選取 **New Folder** 或 **New File**。

請為所有伺服器端檔案建立 **/routes/** 資料夾，為所有用戶端檔案建立 **/public/** 資料夾。

此時，您的專案應具有以下結構：

![](_media/nodejs/vs_code_explorer.png) 

## launch.json

此檔案用來告訴 Visual Studio Code 如何執行我們的 node.js 專案。移往功能表 **Run** >> **Add Configuration...**，然後在顯示於頂部的 **Select Environment** 視窗中選擇 **Node.js**。在建立的 **/.vscode/launch.json** 檔案中輸入以下內容：

!> 請注意，您需要在指定的空白處輸入您的 **Forge Client ID 和 Secret**。

```json
{
    // Use IntelliSense to learn about possible attributes.
    // Hover to view descriptions of existing attributes.
    // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [
        {
            "type": "node",
            "request": "launch",
            "name": "Launch Program",
            "program": "${workspaceFolder}/start.js",
            "env": {
                "FORGE_CLIENT_ID": "your id here",
                "FORGE_CLIENT_SECRET": "your secret here",
                "FORGE_CALLBACK_URL": "http://localhost:3000/api/forge/callback/oauth"
            }
        }
    ]
}
```

> 將您的 **Client ID 和 Secret** 定義為環境變數很重要，這樣我們的專案稍後就可以在線上部署。稍後可在**「部署」**章節中瞭解更多相關資訊。

## start.js

在根資料夾中建立 `start.js` 檔案，其中包含：

!> 有些部署方式的檔案命名方式是有區分大小寫，例如 **Heroku**。所以，在本自學課程中，讓我們在檔名的部分一律使用小寫進行命名。

```javascript
const path = require('path');
const express = require('express');
const cookieSession = require('cookie-session');

const PORT = process.env.PORT || 3000;
const config = require('./config');
if (config.credentials.client_id == null || config.credentials.client_secret == null) {
    console.error('Missing FORGE_CLIENT_ID or FORGE_CLIENT_SECRET env. variables.');
    return;
}

let app = express();
app.use(express.static(path.join(__dirname, 'public')));
app.use(cookieSession({
    name: 'forge_session',
    keys: ['forge_secure_key'],
    secure: (process.env.NODE_ENV === 'production'),
    maxAge: 14 * 24 * 60 * 60 * 1000 // 14 days, same as refresh token
}));
app.use(express.json({ limit: '50mb' }));
app.use('/api/forge', require('./routes/oauth'));
app.use('/api/forge', require('./routes/datamanagement'));
app.use('/api/forge', require('./routes/user'));
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json(err);
});
app.listen(PORT, () => { console.log(`Server listening on port ${PORT}`); });
```

此檔案用於啟動 **Express **伺服器，提供靜態檔案 (例如 `html`) 以及路由 API 請求。

## config.js

在根資料夾中，建立含有以下內容名為 `config.js` 的檔案：

```javascript
// Autodesk Forge configuration
module.exports = {
    // Set environment variables or hard-code here
    credentials: {
        client_id: process.env.FORGE_CLIENT_ID,
        client_secret: process.env.FORGE_CLIENT_SECRET,
        callback_url: process.env.FORGE_CALLBACK_URL
    },
    scopes: {
        // Required scopes for the server-side application
        internal: ['bucket:create', 'bucket:read', 'data:read', 'data:create', 'data:write'],
        // Required scope for the client-side viewer
        public: ['viewables:read']
    }
};
```

在這裡，我們將定義 ENV 變數。執行 Express 伺服器時，這些變數的值將用於連接至我們需要的其他 Autodesk Forge 服務。

最後，我們看到有 2 種範圍定義。內部範圍為 access token 提供了使用 Forge Web Services (伺服器端) 不同服務的適當權限。本自學課程專門介紹 Viewer 的使用，針對公開專案，我們將僅需要「viewables:read」範圍。

專案已準備就緒！此時，您的專案應如下所示：

![](_media/nodejs/vs_code_project.png) 

> **package-lock.json **是因執行上面的 **npm** 命令所產生，請不用擔心。
