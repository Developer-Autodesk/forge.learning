# 建立 .NET WebAPI 控制器

在專案中，於 **Controllers** 資料夾上按一下右鍵，然後移往 **Add** >> **Controller**。

![](_media/net/new_controller.png)

下一步，選取 **Web API 2 Controller - Empty**。 

![](_media/net/new_controller_type.png) 

最後，輸入控制器的名稱。

!> 控制器的字尾**必須**為 **Controller**。

:arrow_backward:在瀏覽器上按一下 **Back** 