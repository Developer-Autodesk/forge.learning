[net 設定](environment/setup/netcore.md ':include :type=markdown')

下一步：[授權](oauth/3legged/)
