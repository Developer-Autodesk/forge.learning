# 開發工具及環境準備

本章節將展示如何準備好您的開發環境，讓您的電腦可以開始使用 **Autodesk Forge API** 或其他雲端 API。如果您有偏好的整合開發環境 (IDE)，可以直接從[「驗證」](oauth/)章節開始。

請選擇您的語言：[Node.js](environment/tools/nodejs) | [.NET Framework](environment/tools/net) | [.NET Core](environment/tools/netcore) | [Go](environment/tools/go) | [PHP](environment/tools/php) | [Java](environment/tools/java)

