# 開發工具及環境準備 (Node.js)

安裝 [Node.js](http://nodejs.org) 引擎以執行程式碼。安裝 [NPM](https://www.npmjs.com/get-npm) 相依性管理員以安裝套件。

現在，我們需要 IDE 來撰寫程式碼。有許多選項可供使用，本自學課程將使用 [Visual Studio Code](https://code.visualstudio.com/)。

> 在本自學課程中，將全部使用預設安裝選項。

下一步：[驗證](oauth/)