# 上傳應用程式組合

現在，ZIP 組合已準備就緒，請上傳至 Design Automation。

請選擇您的語言：[Node.js](designautomation/appbundle/nodejs) | [.NET Core](designautomation/appbundle/netcore)