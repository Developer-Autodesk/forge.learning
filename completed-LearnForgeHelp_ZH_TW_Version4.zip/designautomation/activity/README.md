# 定義 activity

Activity 是指可使用指定引擎執行的動作的規格。將指定輸入和輸出檔案的數目，以及要使用的 AppBundle 和進入點。

在本自學課程範例中，activity 有 2 個輸入 (檔案和 JSON 資料) 和 1 個輸出 (檔案)。

請選擇您的語言：[Node.js](designautomation/activity/nodejs) | [.NET Core](designautomation/activity/netcore)