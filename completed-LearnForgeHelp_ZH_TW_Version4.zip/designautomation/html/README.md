# 基本使用者介面

介面以 vanilla `HTML5` 和 `JavaScript` 為基礎。對於任何伺服器端，它基本上都相同，但有一些差異：Websocket 實作使用的是 socket.io (Node.js) 或 SignalR (.NET Core)。

請選擇您的語言：[Node.js](designautomation/html/nodejs.md) | [.NET Core](designautomation/html/netcore.md)