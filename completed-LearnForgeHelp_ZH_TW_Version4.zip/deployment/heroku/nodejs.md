# Heroku (Nodejs)

[步驟 1](/deployment/heroku/heroku_step1.md ':include :type=markdown')

讓我們使用適用於節點的 Github 樣板：https://github.com/github/gitignore/blob/master/Node.gitignore

[步驟 2](/deployment/heroku/heroku_step2.md ':include :type=markdown')

```bash
heroku create forgesample
heroku git:remote -a forgesample
```

[步驟 3](/deployment/heroku/heroku_step3.md ':include :type=markdown')