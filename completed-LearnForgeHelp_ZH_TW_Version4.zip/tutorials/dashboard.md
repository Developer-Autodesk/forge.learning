# 您的第一個管控面板

本自學課程將引導您讀取資料及建立一些圖表。 

![](_media/tutorials/run_sample_dashboard.gif)

> 就本自學課程而言，您需要具有 Viewer 的應用程式，例如[檢視模型](tutorials/viewmodels.md)或[檢視 BIM 360 與 Fusion 模型](tutorials/viewhubmodels.md)自學課程。無論檔案裝載在何處，Viewer 都是一樣的。

準備好開始撰寫程式碼了嗎？

下一步：[調整配置](viewer/dashboard/layout.md)