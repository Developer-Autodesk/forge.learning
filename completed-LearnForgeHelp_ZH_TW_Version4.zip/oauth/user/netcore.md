# 使用者資訊

此 endpoint 將請求終端使用者資訊，然後傳回**名稱**和**圖片** (40px)。

## UserController.cs

在 **Controllers** 資料夾下，將名為 **UserController** 的類別建立在同名的類別檔案 (`UserController.cs`) 中，然後加入以下內容：

[UserController.cs](_snippets/viewhubmodels/netcore/UserController.cs ':include :type=code csharp')

下一步：[在 Viewer 中展示](viewer/3legged/readme)