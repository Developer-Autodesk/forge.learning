# 使用者資訊 (.NET Framework)

此 endpoint 將請求終端使用者資訊，然後傳回**名稱**和**圖片** (40px)。

## UserController.cs

建立名為 **UserController** 的 .NET WebAPI 控制器 (請參閱[如何建立控制器](environment/setup/net_controller))，然後加入以下內容：

[UserController.cs](_snippets/viewhubmodels/net/UserController.cs ':include :type=code csharp')

下一步：[在 Viewer 中展示](viewer/3legged/readme)