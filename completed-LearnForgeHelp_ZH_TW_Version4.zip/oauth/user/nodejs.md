# 使用者資訊 (Node.js)

此 endpoint 將請求終端使用者資訊，然後傳回**名稱**和**圖片** (40px)。

## routes/user.js

建立 `routes/user.js` 檔案，然後複製以下內容：

[routes/user.js](_snippets/viewhubmodels/node/routes/user.js ':include :type=code javascript')

下一步：[在 Viewer 中展示](viewer/3legged/readme)