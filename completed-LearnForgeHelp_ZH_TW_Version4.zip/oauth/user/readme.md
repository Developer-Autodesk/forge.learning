# 使用者資訊

使用 3 條腿的 access token 時，我們可以取得授權的終端使用者本身的紀要資訊。這包括了能讓自訂的使用者介面看起來更好的**名稱**和**圖片**。[瞭解更多](https://forge.autodesk.com/en/docs/oauth/v2/reference/http/users-@me-GET/)

請選擇您的語言：[Node.js](oauth/user/nodejs) | [.NET Framework](oauth/user/net) | [.NET Core](oauth/user/netcore)
