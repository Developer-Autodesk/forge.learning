# 用戶端檔案 (PHP)

我們的 PHP 伺服器是設定為從 `/www/` 資料夾提供檔案。讓我們組織整理如下：

- `/www/`：`.html` 
- `/www/js`：`.js`
- `/www/css`：`.css`

下圖展示了這樣的組織 (在下一節建立了檔案之後)

![](_media/php/vs_code_allfiles_ui.png)