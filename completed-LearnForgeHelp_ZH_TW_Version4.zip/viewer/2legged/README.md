# Viewer

Viewer 是單純以 `HTML5` 和 `JavaScript` 為基礎的用戶端程式庫。但要想在各伺服器端實作，有一些秘訣： 

請選擇您的語言：[Node.js](viewer/2legged/nodejs) | [.NET Framework](viewer/2legged/net) | [.NET Core](viewer/2legged/netcore) | [Go](viewer/2legged/go) | [PHP](viewer/2legged/php) | [Java](viewer/2legged/java)
