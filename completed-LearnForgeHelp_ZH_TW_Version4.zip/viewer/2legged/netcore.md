[.NET Core 設定](viewer/netcore.md ':include :type=markdown')

![](_media/netcore/project_all_files.png)

下一步：[Viewer (用戶端)](viewer/2legged/ui)
