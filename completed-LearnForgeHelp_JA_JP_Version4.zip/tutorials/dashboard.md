# 最初のダッシュボード

このチュートリアルでは、データを読み込んで、いくつかのチャートを作成する方法について説明します。 

![](_media/tutorials/run_sample_dashboard.gif)

> このチュートリアルでは、「[モデルを表示する](tutorials/viewmodels.md)」や「[BIM 360 および Fusion のモデルを表示する](tutorials/viewhubmodels.md)」のチュートリアルのように、ビューアを持つアプリが必要です。ビューアは、ファイルがホストされている場所に関係なく同じです。

コーディングを開始する準備はできましたか?

次の作業:[レイアウトを調整する](viewer/dashboard/layout.md)