# Heroku (Nodejs)

[ステップ 1](/deployment/heroku/heroku_step1.md ':include :type=markdown')

Node 用の Github テンプレートを使用してみましょう: https://github.com/github/gitignore/blob/master/Node.gitignore

[ステップ 2](/deployment/heroku/heroku_step2.md ':include :type=markdown')

```bash
heroku create forgesample
heroku git:remote -a forgesample
```

[ステップ 3](/deployment/heroku/heroku_step3.md ':include :type=markdown')