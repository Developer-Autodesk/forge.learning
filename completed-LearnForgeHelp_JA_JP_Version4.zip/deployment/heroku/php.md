# Heroku (PHP)

[ステップ 1](/deployment/heroku/heroku_step1.md ':include :type=markdown')

次のコンテンツを使用しましょう。 
```
vendor/
.vscode/
.DS_Store
Thumbs.db
```

[ステップ 2](/deployment/heroku/heroku_step2.md ':include :type=markdown')

```bash
heroku create forgesample
heroku git:remote -a forgesample
```

[ステップ 3](/deployment/heroku/heroku_step3.md ':include :type=markdown')