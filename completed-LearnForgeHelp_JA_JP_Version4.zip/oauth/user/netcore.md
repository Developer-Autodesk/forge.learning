# ユーザ情報

このエンドポイントはエンドユーザ情報をリクエストし、**名前**と**画像**(40px)を返します。

## UserController.cs

**Controllers**フォルダ内の同じ名前(`UserController.cs`)のクラス ファイルに **UserController** という名前のクラスを作成して、次の内容を追加します。

[UserController.cs](_snippets/viewhubmodels/netcore/UserController.cs ':include :type=code csharp')

次の作業:[ビューアに表示する](viewer/3legged/readme)