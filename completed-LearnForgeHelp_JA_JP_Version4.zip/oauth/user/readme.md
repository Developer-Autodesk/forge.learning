# ユーザ情報

3-legged アクセス トークンを使用する場合は、認可元エンド ユーザのプロファイル情報を取得します。プロファイル情報には**名前**および**画像**が含まれていて、ユーザ インタフェースを効率よくカスタマイズするのに役立ちます。[詳細情報](https://forge.autodesk.com/en/docs/oauth/v2/reference/http/users-@me-GET/)

言語を選択:[Node.js](oauth/user/nodejs) | [.NET Framework](oauth/user/net) | [.NET Core](oauth/user/netcore)
