# ユーザ情報(Node.js)

このエンドポイントはエンドユーザ情報をリクエストし、**名前**と**画像**(40px)を返します。

## routes/user.js

`routes/user.js` ファイルを作成し、次の内容をコピーします。

[routes/user.js](_snippets/viewhubmodels/node/routes/user.js ':include :type=code javascript')

次の作業:[ビューアに表示する](viewer/3legged/readme)