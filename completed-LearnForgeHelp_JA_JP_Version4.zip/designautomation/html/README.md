# 基本 UI

インタフェースは、標準の `HTML5` および `JavaScript` に基づいています。基本的にはどのサーバ側でも同じですが、いくつかの違いがあります。Websocket の実装では socket.io (Node.js)または SignalR (.NET Core)を使用します。

言語を選択:[Node.js](designautomation/html/nodejs.md) | [.NET Core](designautomation/html/netcore.md)