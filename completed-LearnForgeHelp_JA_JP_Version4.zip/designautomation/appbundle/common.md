# AppBundle をアップロードする

ZIP バンドルの準備ができました。Design Automation にアップロードしましょう。

言語を選択:[Node.js](designautomation/appbundle/nodejs) | [.NET Core](designautomation/appbundle/netcore)