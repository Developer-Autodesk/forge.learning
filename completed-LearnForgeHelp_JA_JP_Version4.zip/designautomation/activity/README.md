# Activity を定義する

Activity は、指定したエンジンを使用して実行できるアクションを指定します。入力ファイルと出力ファイルの数、および使用する AppBundle とエントリ ポイントを指定します。

このチュートリアル サンプルでは、Activity に 2 つの入力(ファイルと JSON データ)と 1 つの出力(ファイル)があります。

言語を選択:[Node.js](designautomation/activity/nodejs) | [.NET Core](designautomation/activity/netcore)