# 実行とデバッグ(.NET)

Visual Studio で作成した WebAPI プロジェクトにはファイルが含まれていないため、プロジェクトを開始しても何も実行されません。**forgesample** プロジェクトに `index.html` が追加されたため、これを右クリックして **Set as Start Page** を選択します。

プロジェクトを開始するには、Visual Studio がマシン上のすべてのブラウザを認識して、一覧表示する必要があります。いずれかのブラウザを選択して、\[再生]アイコンをクリックします。ブラウザが開き、スタート ページが表示されます。

![](_media/net/start_debug.png) 

次の作業:[ビューアのエクステンション](tutorials/extensions)