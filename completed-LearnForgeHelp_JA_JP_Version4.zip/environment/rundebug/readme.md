# ローカルに実行してデバッグする

どのチュートリアルを実行していますか。

- [モデルを表示する](environment/rundebug/2legged.md)


- [BIM 360 と Fusion のモデルを表示する](environment/rundebug/3legged.md)


- [モデルを修正する](environment/rundebug/2legged_da.md)