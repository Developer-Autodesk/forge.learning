# 実行とデバッグ(.NET Core)

Visual Studio で作成した .NET Core ASP.NET プロジェクトは空であるため、プロジェクトを開始しても何も実行されません。**forgeSample** プロジェクトに `wwwroot/index.html` の開始ページが追加されたため、起動時に内容が表示されます。

システムで使用可能なすべてのブラウザが Visual Studio によって一覧表示されるため、プロジェクト開始時に 1 つを選択できます。いずれかのブラウザを選択して、\[再生]アイコンをクリックします。ブラウザが開き、スタート ページが表示されます。

![](_media/net/start_debug.png)

次の作業:[デプロイ](deployment/)
