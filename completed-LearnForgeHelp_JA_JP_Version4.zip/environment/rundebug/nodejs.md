# 実行とデバッグ(NodeJS)

**Debug** メニューに移動し、**Start debugging** を選択します。次のように、下部に Debug Console タブが表示されます。

![](_media/nodejs/vs_code_debug.png) 

ブラウザを開き、[http://localhost:3000](http://localhost:3000) に移動します。

次の作業:[ビューアのエクステンション](tutorials/extensions)