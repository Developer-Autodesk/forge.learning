# ツール(Node.js)

コードを実行するには、[Node.js](http://nodejs.org) エンジンをインストールします。パッケージをインストールするには、[NPM](https://www.npmjs.com/get-npm) 依存関係マネージャをインストールします。

次に、コードを記述するための IDE が必要です。多くのオプションがありますが、このチュートリアルでは、[Visual Studio Code](https://code.visualstudio.com/) を使用します。

> このチュートリアルでは、すべての既定のインストール オプションを使用します。

次の作業:[認証](oauth/)