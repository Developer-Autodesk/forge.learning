# ツール

このセクションでは、**Autodesk Forge** または他のクラウド API を使用するようにマシンを準備する方法について説明します。プリファレンスの IDE が既にある場合は、「[認証](oauth/)」にスキップできます。

言語を選択:[Node.js](environment/tools/nodejs) | [.NET Framework](environment/tools/net) | [.NET Core](environment/tools/netcore) | [Go](environment/tools/go) | [PHP](environment/tools/php) | [Java](environment/tools/java)

