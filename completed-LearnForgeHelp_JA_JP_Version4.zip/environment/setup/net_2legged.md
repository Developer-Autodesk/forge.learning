[net のセットアップ](environment/setup/net.md ':include :type=markdown')

プロジェクトの準備ができました!

次の作業:[認証する](oauth/2legged/)