# .NET WebAPI コントローラを作成する

プロジェクトで**Controllers** フォルダを右クリックし、**Add** >> **Controller** の順に選択します。

![](_media/net/new_controller.png)

次に、**Web API 2 Controller - Empty** を選択します。 

![](_media/net/new_controller_type.png) 

最後に、コントローラの名前を入力します。

!> コントローラには **Controller** という接尾辞を**付ける必要があります**。

:arrow_backward:ブラウザで **Back** をクリックします 