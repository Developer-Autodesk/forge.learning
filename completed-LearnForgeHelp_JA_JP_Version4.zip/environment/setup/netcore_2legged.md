[net のセットアップ](environment/setup/netcore.md ':include :type=markdown')

次の作業:[認証する](oauth/2legged/)
