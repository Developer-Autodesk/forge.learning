# サーバを作成する

すべてのファイルがアカウントにバインドされるため、Client ID と Secret を保護し、機密を維持する必要があります。Web アプリケーションの場合は、サーバに保存してください。このセクションでは、ローカル開発サーバを作成するための準備方法を示します。

言語を選択:[Node.js](environment/setup/nodejs_3legged) | [.NET Framework](environment/setup/net_3legged) | [.NET Core](environment/setup/netcore_3legged) 
