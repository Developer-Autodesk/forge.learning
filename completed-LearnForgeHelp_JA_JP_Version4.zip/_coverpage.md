![Autodesk Forge](_media/logo.png)

# Autodesk Forge

> ものづくりの未来を後押しする。

- ブラウザで 2D および 3D モデルを表示
- メタデータを抽出してファイルを変換
- モデルの対話処理

[開発者ポータル](http://forge.autodesk.com) [スタートアップ](#learn-autodesk-forge)