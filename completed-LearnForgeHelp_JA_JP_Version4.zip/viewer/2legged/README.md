# ビューア

ビューアは、純粋な `HTML5` および `JavaScript` に基づくクライアント側ライブラリです。ただし、サーバ側の実装ごとにいくつかのヒントがあります。 

言語を選択:[Node.js](viewer/2legged/nodejs) | [.NET Framework](viewer/2legged/net) | [.NET Core](viewer/2legged/netcore) | [Go](viewer/2legged/go) | [PHP](viewer/2legged/php) | [Java](viewer/2legged/java)
