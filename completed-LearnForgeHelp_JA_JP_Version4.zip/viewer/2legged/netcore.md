[.NET Core のセットアップ](viewer/netcore.md ':include :type=markdown')

![](_media/netcore/project_all_files.png)

次の作業:[ビューア(クライアント側)](viewer/2legged/ui)
