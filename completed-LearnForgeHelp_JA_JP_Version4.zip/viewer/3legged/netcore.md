[netcore のセットアップ](viewer/netcore.md ':include :type=markdown')

![](_media/netcore/project_all_files_3lo.png)

次の作業:[ビューア(クライアント側)](viewer/3legged/ui)