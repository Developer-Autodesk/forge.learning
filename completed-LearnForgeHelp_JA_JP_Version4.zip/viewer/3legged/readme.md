# ビューア

ビューアは、純粋な `HTML5` および `JavaScript` に基づくクライアント側ライブラリです。ただし、サーバ側の実装ごとにいくつかのヒントがあります。 

言語を選択:[Node.js](viewer/3legged/nodejs) | [.NET Framework](viewer/3legged/net) | [.NET Core](viewer/3legged/netcore)