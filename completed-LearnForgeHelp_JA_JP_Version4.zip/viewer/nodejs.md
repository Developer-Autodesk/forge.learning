# クライアント側ファイル(Node.js)

Node.js サーバは、`public` フォルダのファイルを処理するように設定されています。内容を次のように整理してみましょう。

- `public/`: `.html` 
- `public/js`: `.js`
- `public/css`: `.css`

以下の図に、次のセクションでファイルを作成した後に予期される構造を示します。

![](_media/nodejs/vs_code_allfiles_ui.png)