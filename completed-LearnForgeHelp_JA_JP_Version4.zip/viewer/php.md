# クライアント側ファイル(PHP)

PHP サーバは、`/www/` フォルダのファイルを処理するように設定されています。次のように整理してみましょう。

- `/www/`: `.html` 
- `/www/js`: `.js`
- `/www/css`: `.css`

以下の図に、次のセクションでファイルを作成した後の内容を示します。

![](_media/php/vs_code_allfiles_ui.png)